class DB():
    BuiltInParameter = None
    BuiltInCategory = None
    ElementId = None

doc = None
uidoc = None
version = None
platform = None
DB = DB()
List = None
