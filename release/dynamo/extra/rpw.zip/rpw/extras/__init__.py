""" Additional Classes that do not wrap API Objects """

import sys
import os

binary_path = os.path.join(os.path.dirname(__file__), 'bin')
sys.path.append(binary_path)
